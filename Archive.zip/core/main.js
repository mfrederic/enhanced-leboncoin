'use strict';
const constants = new Constants();
const cssHelper = new CssHelper();

$(function() {
  new Enhanced();
});
