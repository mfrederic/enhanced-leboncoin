# enhanced-leboncoin
Project to build a web extension to improve and add functionalities to Leboncoin.fr website
